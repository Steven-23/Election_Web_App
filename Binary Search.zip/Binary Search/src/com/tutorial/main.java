package com.tutorial;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class main {

    //ref: https://www.geeksforgeeks.org/binary-search-a-string/

    static int binarySearch(String arr[], String x){
        int first = 0;
        int last = arr.length-1;

        while(first <= last){
            int m = first + (last - 1)/2;
            System.out.println(m);
            int res = x.compareTo(arr[m]);

            if(res == 0)
                return m;

            if(res > 0)
                first = m + 1;

            else
                last = m + 1;
        }
        return -1;
    }

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("C:/Users/kwanl/OneDrive/Documents/Java Advance/nameSorted.txt");
        Scanner scan = new Scanner(file);

        String [] sorted_name = new String[18239]; 
        String [] search_name = {"Aaren"}; 
        String target = "Aaren";

        int idx = 0;
        while(scan.hasNextLine()){
            sorted_name[idx] = scan.nextLine();
            idx++;
        }
        
        int result = binarySearch(sorted_name, target);

        if (result == -1)
        System.out.println("Element not present");
        else
        System.out.println("Element found at "
                          + "index " + result);
    }
}
